import SwiftUI

struct ConverterView: View {
    @EnvironmentObject var engine: CalculatorEngine
    @Environment(\.dismiss) private var dismiss

    @State private var category: ConvCategory = .length
    @State private var fromUnit = "m"
    @State private var toUnit   = "ft"
    @State private var input    = ""
    @State private var result   = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Category") {
                    Picker("Category", selection: $category) {
                        ForEach(ConvCategory.allCases) { c in
                            Label(c.rawValue, systemImage: c.icon).tag(c)
                        }
                    }
                    .pickerStyle(.menu)
                    .onChange(of: category) { _, _ in resetUnits(); convert() }
                }

                Section("Units") {
                    Picker("From", selection: $fromUnit) {
                        ForEach(category.units, id: \.self) { Text($0).tag($0) }
                    }
                    .onChange(of: fromUnit) { _, _ in convert() }

                    Picker("To", selection: $toUnit) {
                        ForEach(category.units, id: \.self) { Text($0).tag($0) }
                    }
                    .onChange(of: toUnit) { _, _ in convert() }
                }

                Section {
                    HStack {
                        TextField("Value", text: $input)
                            .keyboardType(.decimalPad)
                            .onChange(of: input) { _, _ in convert() }
                        Button {
                            input = engine.display
                            convert()
                        } label: {
                            Label("Use display", systemImage: "arrow.down.to.line")
                                .labelStyle(.iconOnly)
                        }
                        .buttonStyle(.bordered)
                        .tint(.accentColor)
                    }
                } header: {
                    Text("Value")
                }

                if !result.isEmpty {
                    Section("Result") {
                        Text(result)
                            .font(.system(size: 28, weight: .semibold, design: .rounded))
                            .foregroundStyle(.primary)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                            .onTapGesture {
                                UIPasteboard.general.string = result
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                            }
                    }
                }
            }
            .navigationTitle("Unit Converter")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
    }

    private func resetUnits() {
        let u = category.units
        fromUnit = u[0]
        toUnit   = u.count > 1 ? u[1] : u[0]
    }

    private func convert() {
        guard let v = Double(input.replacingOccurrences(of: ",", with: ".")) else { result = ""; return }
        let out = fromBase(toBase(v, unit: fromUnit), unit: toUnit)
        if out.isNaN || out.isInfinite { result = "—"; return }
        let f = NumberFormatter(); f.numberStyle = .decimal; f.maximumSignificantDigits = 8
        result = (f.string(from: NSNumber(value: out)) ?? "\(out)") + " \(toUnit)"
    }

    private func toBase(_ v: Double, unit: String) -> Double {
        switch category {
        case .length:
            switch unit { case "m":return v;case "km":return v*1000;case "cm":return v/100;case "mm":return v/1000;case "mi":return v*1609.344;case "ft":return v*0.3048;case "in":return v*0.0254;case "yd":return v*0.9144;default:return v }
        case .weight:
            switch unit { case "kg":return v;case "g":return v/1000;case "lb":return v*0.453592;case "oz":return v*0.0283495;case "t":return v*1000;case "mg":return v/1e6;default:return v }
        case .temperature:
            switch unit { case "°C":return v;case "°F":return(v-32)*5/9;case "K":return v-273.15;default:return v }
        case .area:
            switch unit { case "m²":return v;case "km²":return v*1e6;case "cm²":return v/1e4;case "ft²":return v*0.092903;case "in²":return v*0.00064516;case "ha":return v*10000;case "acre":return v*4046.86;default:return v }
        case .volume:
            switch unit { case "L":return v;case "mL":return v/1000;case "gal":return v*3.78541;case "fl oz":return v*0.0295735;case "cup":return v*0.236588;case "tbsp":return v*0.0147868;case "tsp":return v*0.00492892;case "m³":return v*1000;default:return v }
        case .speed:
            switch unit { case "m/s":return v;case "km/h":return v/3.6;case "mph":return v*0.44704;case "knot":return v*0.514444;case "ft/s":return v*0.3048;default:return v }
        }
    }

    private func fromBase(_ v: Double, unit: String) -> Double {
        switch category {
        case .length:
            switch unit { case "m":return v;case "km":return v/1000;case "cm":return v*100;case "mm":return v*1000;case "mi":return v/1609.344;case "ft":return v/0.3048;case "in":return v/0.0254;case "yd":return v/0.9144;default:return v }
        case .weight:
            switch unit { case "kg":return v;case "g":return v*1000;case "lb":return v/0.453592;case "oz":return v/0.0283495;case "t":return v/1000;case "mg":return v*1e6;default:return v }
        case .temperature:
            switch unit { case "°C":return v;case "°F":return v*9/5+32;case "K":return v+273.15;default:return v }
        case .area:
            switch unit { case "m²":return v;case "km²":return v/1e6;case "cm²":return v*1e4;case "ft²":return v/0.092903;case "in²":return v/0.00064516;case "ha":return v/10000;case "acre":return v/4046.86;default:return v }
        case .volume:
            switch unit { case "L":return v;case "mL":return v*1000;case "gal":return v/3.78541;case "fl oz":return v/0.0295735;case "cup":return v/0.236588;case "tbsp":return v/0.0147868;case "tsp":return v/0.00492892;case "m³":return v/1000;default:return v }
        case .speed:
            switch unit { case "m/s":return v;case "km/h":return v*3.6;case "mph":return v/0.44704;case "knot":return v/0.514444;case "ft/s":return v/0.3048;default:return v }
        }
    }
}

// MARK: - ConvCategory (shared model)

enum ConvCategory: String, CaseIterable, Identifiable {
    case length="Length", weight="Weight", temperature="Temperature"
    case area="Area", volume="Volume", speed="Speed"
    var id: String { rawValue }
    var icon: String {
        switch self { case .length:"ruler"; case .weight:"scalemass"; case .temperature:"thermometer"
                      case .area:"square"; case .volume:"drop"; case .speed:"gauge.with.dots.needle.67percent" }
    }
    var units: [String] {
        switch self {
        case .length:      return ["m","km","cm","mm","mi","ft","in","yd"]
        case .weight:      return ["kg","g","lb","oz","t","mg"]
        case .temperature: return ["°C","°F","K"]
        case .area:        return ["m²","km²","cm²","ft²","in²","ha","acre"]
        case .volume:      return ["L","mL","gal","fl oz","cup","tbsp","tsp","m³"]
        case .speed:       return ["m/s","km/h","mph","knot","ft/s"]
        }
    }
}
