import SwiftUI

// MARK: - Button kind

enum CalcButtonKind { case number, operatorKey, function_, equals, memory }

// MARK: - Calc Button

struct CalcBtn: View {
    let label: String
    let kind: CalcButtonKind
    let width: CGFloat
    let height: CGFloat
    let action: () -> Void

    init(_ label: String, kind: CalcButtonKind, w: CGFloat, h: CGFloat, action: @escaping () -> Void) {
        self.label = label; self.kind = kind
        self.width = w; self.height = h; self.action = action
    }

    var body: some View {
        Button {
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            action()
        } label: {
            Text(label)
                .font(labelFont)
                .frame(width: width, height: height)
                .background(bgColor)
                .foregroundStyle(fgColor)
                .clipShape(RoundedRectangle(cornerRadius: 16))
        }
        .buttonStyle(.plain)
    }

    private var labelFont: Font {
        switch kind {
        case .operatorKey, .equals: return .system(size: 30, weight: .medium)
        case .function_:            return .system(size: 20, weight: .medium)
        case .memory:               return .system(size: 15, weight: .semibold)
        default:                    return .system(size: 30, weight: .regular)
        }
    }

    private var bgColor: Color {
        switch kind {
        case .number:      return Color(.systemGray4)
        case .operatorKey: return .orange
        case .function_:   return Color(.systemGray2)
        case .equals:      return .orange
        case .memory:      return .purple.opacity(0.75)
        }
    }

    private var fgColor: Color {
        switch kind {
        case .number, .function_: return .primary
        default:                  return .white
        }
    }
}

// MARK: - Content View

struct ContentView: View {
    @EnvironmentObject var engine: CalculatorEngine
    @AppStorage("isScientific")   private var isScientific = false
    @State private var showHistory   = false
    @State private var showConverter = false
    @Environment(\.horizontalSizeClass) private var hSize

    var body: some View {
        NavigationStack {
            GeometryReader { geo in
                let isLandscape = geo.size.width > geo.size.height
                if isLandscape {
                    landscapeLayout(geo: geo)
                } else {
                    portraitLayout(geo: geo)
                }
            }
            .background(Color(.systemBackground))
            .navigationBarHidden(true)
        }
        .sheet(isPresented: $showHistory)   { HistoryView().environmentObject(engine) }
        .sheet(isPresented: $showConverter) { ConverterView().environmentObject(engine) }
    }

    // MARK: Portrait

    private func portraitLayout(geo: GeometryProxy) -> some View {
        VStack(spacing: 0) {
            toolbar
            Spacer(minLength: 0)
            displayArea
            if isScientific {
                sciPanel(geo: geo)
                    .transition(.move(edge: .top).combined(with: .opacity))
            }
            keypad(geo: geo)
                .padding(.bottom, max(geo.safeAreaInsets.bottom, 8))
        }
        .animation(.easeInOut(duration: 0.2), value: isScientific)
    }

    // MARK: Landscape — sci panel left, keypad right

    private func landscapeLayout(geo: GeometryProxy) -> some View {
        HStack(spacing: 0) {
            VStack(spacing: 0) {
                toolbar
                Spacer(minLength: 0)
                displayArea
            }
            .frame(width: geo.size.width * 0.38)

            Divider()

            VStack(spacing: 0) {
                sciPanelLandscape(geo: geo)
            }
            .frame(width: geo.size.width * 0.30)

            Divider()

            VStack(spacing: 0) {
                keypad(geo: geo, compact: true)
                    .padding(.bottom, max(geo.safeAreaInsets.bottom, 4))
            }
            .frame(width: geo.size.width * 0.32)
        }
    }

    // MARK: Toolbar

    private var toolbar: some View {
        HStack(spacing: 10) {
            Text("CalcYouLater")
                .font(.system(size: 17, weight: .semibold, design: .rounded))
            Spacer()
            toolbarBtn(icon: "clock.arrow.circlepath", active: showHistory) {
                showHistory.toggle(); showConverter = false
            }
            toolbarBtn(icon: "arrow.left.arrow.right.circle", active: showConverter) {
                showConverter.toggle(); showHistory = false
            }
            Button { isScientific.toggle() } label: {
                Text("Sci")
                    .font(.system(size: 12, weight: .bold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(isScientific ? Color.accentColor.opacity(0.2) : Color(.tertiarySystemFill))
                    .foregroundStyle(isScientific ? Color.accentColor : .secondary)
                    .clipShape(Capsule())
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 12)
        .padding(.bottom, 8)
    }

    private func toolbarBtn(icon: String, active: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 18))
                .symbolVariant(active ? .fill : .none)
                .foregroundStyle(active ? Color.accentColor : .secondary)
                .frame(width: 36, height: 36)
                .background(active ? Color.accentColor.opacity(0.12) : Color(.tertiarySystemFill))
                .clipShape(RoundedRectangle(cornerRadius: 8))
        }
    }

    // MARK: Display

    private var displayArea: some View {
        VStack(alignment: .trailing, spacing: 2) {
            Text(engine.expression.isEmpty ? " " : engine.expression)
                .font(.system(size: 16, design: .monospaced))
                .foregroundStyle(.secondary)
                .lineLimit(1)
                .truncationMode(.head)

            Text(engine.display)
                .font(.system(size: 72, weight: .thin, design: .rounded))
                .foregroundStyle(.primary)
                .lineLimit(1)
                .minimumScaleFactor(0.28)
                .onTapGesture {
                    UIPasteboard.general.string = engine.display
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                }
                .help("Tap to copy")

            HStack {
                if engine.hasMemory {
                    Text("M: \(engine.fmt(engine.memory))")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(.purple)
                }
                Spacer()
            }
            .frame(height: 18)
        }
        .frame(maxWidth: .infinity, alignment: .trailing)
        .padding(.horizontal, 20)
        .padding(.bottom, 8)
    }

    // MARK: Standard Keypad

    private func keypad(geo: GeometryProxy, compact: Bool = false) -> some View {
        let pad: CGFloat  = compact ? 8 : 16
        let gap: CGFloat  = compact ? 7 : 10
        let cols: CGFloat = 4
        let availW = (compact ? geo.size.width * 0.32 : geo.size.width) - 2*pad - (cols-1)*gap
        let bw = availW / cols
        let bh = compact ? bw * 0.72 : bw * 0.84
        let memH = compact ? bh * 0.60 : bh * 0.62

        return VStack(spacing: gap) {
            memRow(bw: bw, bh: memH, gap: gap)
            HStack(spacing: gap) {
                CalcBtn(engine.clearLabel, kind: .function_, w: bw, h: bh) { engine.clear() }
                CalcBtn("+/−", kind: .function_, w: bw, h: bh) { engine.toggleSign() }
                CalcBtn("%",   kind: .function_, w: bw, h: bh) { engine.percent() }
                CalcBtn("÷",   kind: .operatorKey, w: bw, h: bh) { engine.inputOperator("÷") }
            }
            ForEach([["7","8","9","×"],["4","5","6","−"],["1","2","3","+"]], id: \.self) { row in
                HStack(spacing: gap) {
                    ForEach(row.dropLast(), id: \.self) { d in
                        CalcBtn(d, kind: .number, w: bw, h: bh) { engine.inputDigit(d) }
                    }
                    CalcBtn(row[3], kind: .operatorKey, w: bw, h: bh) { engine.inputOperator(row[3]) }
                }
            }
            HStack(spacing: gap) {
                CalcBtn("0", kind: .number, w: bw*2+gap, h: bh) { engine.inputDigit("0") }
                CalcBtn(".", kind: .number, w: bw, h: bh) { engine.inputDecimal() }
                CalcBtn("=", kind: .equals, w: bw, h: bh) { engine.equals() }
            }
        }
        .padding(.horizontal, pad)
        .padding(.bottom, gap)
    }

    private func memRow(bw: CGFloat, bh: CGFloat, gap: CGFloat) -> some View {
        HStack(spacing: gap) {
            CalcBtn("MC", kind: .memory, w: bw, h: bh) { engine.memoryClear() }
            CalcBtn("MR", kind: .memory, w: bw, h: bh) { engine.memoryRecall() }
            CalcBtn("M+", kind: .memory, w: bw, h: bh) { engine.memoryAdd() }
            CalcBtn("M−", kind: .memory, w: bw, h: bh) { engine.memorySubtract() }
        }
    }

    // MARK: Scientific Panel (portrait — above keypad)

    private func sciPanel(geo: GeometryProxy) -> some View {
        let pad: CGFloat = 16, gap: CGFloat = 8, cols: CGFloat = 4
        let bw = (geo.size.width - 2*pad - (cols-1)*gap) / cols
        let bh = bw * 0.54
        return sciGrid(bw: bw, bh: bh, gap: gap)
            .padding(.horizontal, pad)
            .padding(.bottom, gap)
    }

    private func sciPanelLandscape(geo: GeometryProxy) -> some View {
        let pad: CGFloat = 6, gap: CGFloat = 6, cols: CGFloat = 4
        let bw = (geo.size.width * 0.30 - 2*pad - (cols-1)*gap) / cols
        let bh = bw * 0.72
        return VStack {
            Spacer()
            sciGrid(bw: bw, bh: bh, gap: gap)
                .padding(.horizontal, pad)
                .padding(.bottom, gap)
        }
    }

    private func sciGrid(bw: CGFloat, bh: CGFloat, gap: CGFloat) -> some View {
        let rows = [
            [("sin","sin"),("cos","cos"),("tan","tan"),("π","π")],
            [("sin⁻¹","asin"),("cos⁻¹","acos"),("tan⁻¹","atan"),("e","e")],
            [("log","log"),("ln","ln"),("√","sqrt"),("x²","x²")],
            [("xʸ","xʸ"),("n!","n!"),("1/x","1/x"),("∛x","cbrt")],
        ]
        return VStack(spacing: gap) {
            ForEach(rows, id: \.self.map(\.0).description) { row in
                HStack(spacing: gap) {
                    ForEach(row, id: \.0) { (label, fn) in
                        sciBtn(label: label, fn: fn, w: bw, h: bh)
                    }
                }
            }
        }
    }

    private func sciBtn(label: String, fn: String, w: CGFloat, h: CGFloat) -> some View {
        Button {
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
            switch fn {
            case "π": engine.inputConstant("π")
            case "e": engine.inputConstant("e")
            case "xʸ": engine.inputOperator("xʸ")
            default:   engine.applyScientific(fn)
            }
        } label: {
            Text(label)
                .font(.system(size: min(w * 0.28, 15), weight: .medium, design: .rounded))
                .frame(width: w, height: h)
                .background(Color.indigo.opacity(0.15))
                .foregroundStyle(Color.indigo)
                .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .buttonStyle(.plain)
    }
}
