import SwiftUI

struct HistoryView: View {
    @EnvironmentObject var engine: CalculatorEngine
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Group {
                if engine.history.isEmpty {
                    ContentUnavailableView(
                        "No History Yet",
                        systemImage: "clock.arrow.circlepath",
                        description: Text("Your calculations will appear here.")
                    )
                } else {
                    List {
                        ForEach(engine.history) { entry in
                            Button { engine.recallHistory(entry); dismiss() } label: {
                                VStack(alignment: .trailing, spacing: 3) {
                                    Text(entry.expression)
                                        .font(.system(size: 13, design: .monospaced))
                                        .foregroundStyle(.secondary)
                                        .frame(maxWidth: .infinity, alignment: .trailing)
                                        .lineLimit(1)
                                        .truncationMode(.head)

                                    Text(entry.result)
                                        .font(.system(size: 22, weight: .semibold, design: .rounded))
                                        .foregroundStyle(.primary)
                                        .frame(maxWidth: .infinity, alignment: .trailing)

                                    Text(entry.timestamp, style: .time)
                                        .font(.system(size: 11))
                                        .foregroundStyle(.tertiary)
                                        .frame(maxWidth: .infinity, alignment: .trailing)
                                }
                                .padding(.vertical, 4)
                            }
                            .buttonStyle(.plain)
                        }
                        .onDelete { engine.history.remove(atOffsets: $0) }
                    }
                    .listStyle(.insetGrouped)
                }
            }
            .navigationTitle("History")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    if !engine.history.isEmpty {
                        Button("Clear", role: .destructive) { engine.clearHistory() }
                    }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
    }
}
