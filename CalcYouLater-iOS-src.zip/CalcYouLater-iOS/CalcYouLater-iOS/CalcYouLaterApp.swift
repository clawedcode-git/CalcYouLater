import SwiftUI

@main
struct CalcYouLaterApp: App {
    @StateObject private var engine = CalculatorEngine()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(engine)
        }
    }
}
